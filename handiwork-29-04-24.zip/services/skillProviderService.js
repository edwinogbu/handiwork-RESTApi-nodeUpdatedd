// const mysql = require('mysql');
// const bcrypt = require('bcrypt');
// const jwt = require('jsonwebtoken');
// const axios = require('axios');
// const dotenv = require('dotenv');

// dotenv.config();

// const connection = mysql.createPool({
//     host: process.env.DB_HOST,
//     user: process.env.DB_USER,
//     password: process.env.DB_PASSWORD,
//     database: process.env.DB_NAME,
// });

// // Helper function to execute SQL queries
// function query(sql, args) {
//     return new Promise((resolve, reject) => {
//         connection.query(sql, args, (err, rows) => {
//             if (err) reject(err);
//             else resolve(rows);
//         });
//     });
// }

// // Function to sign JWT token
// const signToken = (id) => {
//     return jwt.sign({ id }, process.env.JWT_SECRET, {
//         expiresIn: process.env.JWT_EXPIRES_IN,
//     });
// };

// async function createSkillProvidersTable() {
//     const createSkillProvidersTableQuery = `
//         CREATE TABLE IF NOT EXISTS skill_providers (
//             id INT AUTO_INCREMENT PRIMARY KEY,
//             firstName VARCHAR(255) NOT NULL,
//             lastName VARCHAR(255) NOT NULL,
//             email VARCHAR(255),
//             password VARCHAR(255) NOT NULL,
//             phone VARCHAR(20),
//             secondPhone VARCHAR(20),
//             stateOfResidence VARCHAR(255) NOT NULL,
//             city VARCHAR(255) NOT NULL,
//             street VARCHAR(255) NOT NULL,
//             address VARCHAR(255),
//             serviceTypeId INT,
//             subCategoryId INT,
//             openingHour VARCHAR(255),
//             referralCode VARCHAR(255),
//             imagePath VARCHAR(255),
//             userId INT,
//             FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
//             FOREIGN KEY (serviceTypeId) REFERENCES skill_types(id),
//             FOREIGN KEY (subCategoryId) REFERENCES skill_types(id),
//             latitude DECIMAL(10, 8),
//             longitude DECIMAL(11, 8),
//             createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
//             updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
//         );
//     `;
//     try {
//         await query(createSkillProvidersTableQuery);
//         console.log('SkillProviders table created successfully');
//     } catch (error) {
//         console.error('Error creating SkillProviders table:', error);
//         throw error;
//     }
// }

// async function createSkillTypesTable() {
//     const createSkillTypesTableQuery = `
//         CREATE TABLE IF NOT EXISTS skill_types (
//             id INT AUTO_INCREMENT PRIMARY KEY,
//             serviceType VARCHAR(255) NOT NULL,
//             subCategory VARCHAR(255) NOT NULL,
//             UNIQUE(serviceType, subCategory)
//         );
//     `;
//     try {
//         await query(createSkillTypesTableQuery);
//         console.log('SkillTypes table created successfully');
//     } catch (error) {
//         console.error('Error creating SkillTypes table:', error);
//         throw error;
//     }
// }

// createSkillProvidersTable(); // Immediately create the skill_providers table on module load
// createSkillTypesTable(); // Immediately create the skill_types table on module load

// const skillProviderService = {};

// skillProviderService.emailExists = async (email) => {
//     try {
//         let selectQuery;
//         let queryParams;
        
//         if (email === null) {
//             selectQuery = 'SELECT COUNT(*) AS count FROM skill_providers WHERE email IS NULL';
//             queryParams = [];
//         } else {
//             selectQuery = 'SELECT COUNT(*) AS count FROM skill_providers WHERE email = ?';
//             queryParams = [email];
//         }

//         const result = await query(selectQuery, queryParams);
//         const count = result[0].count;
//         return count > 0;
//     } catch (error) {
//         throw error;
//     }
// };

// skillProviderService.phoneExists = async (phone) => {
//     try {
//         const selectQuery = 'SELECT COUNT(*) AS count FROM users WHERE phone = ?';
//         const result = await query(selectQuery, [phone]);
//         const count = result[0].count;
//         return count > 0;
//     } catch (error) {
//         throw error;
//     }
// };

// // skillProviderService.createSkillProvider = async (skillProviderData) => {
// //     try {
// //         const { firstName, lastName, email, password, phone, secondPhone, stateOfResidence, city, street, serviceType, subCategory, openingHour, referralCode, imagePath } = skillProviderData;

// //         // Check if email or phone already exists
// //         const emailExists = await skillProviderService.emailExists(email);
// //         if (emailExists) {
// //             throw new Error('Email already exists');
// //         }

// //         const phoneExists = await skillProviderService.phoneExists(phone);
// //         if (phoneExists) {
// //             throw new Error('Phone number already exists');
// //         }

// //         // Hash the password
// //         const hashedPassword = await bcrypt.hash(password, 12);

// //         // Construct full address
// //         const address = `${street}, ${city}, ${stateOfResidence}`;

// //         // Insert data into skill_types table for service type and subcategory
// //         const [serviceTypeResult] = await query('INSERT IGNORE INTO skill_types (serviceType, subCategory) VALUES (?, ?)', [serviceType, subCategory]);

// //         // Retrieve the service type and subcategory IDs
// //         const serviceTypeId = serviceTypeResult.insertId;

// //         // Insert data into skill_providers table
// //         const insertProviderQuery = `
// //             INSERT INTO skill_providers (firstName, lastName, email, password, phone, secondPhone, stateOfResidence, city, street, address, serviceTypeId, subCategoryId, openingHour, referralCode, imagePath)
// //             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
// //         `;
// //         const providerResult = await query(insertProviderQuery, [firstName, lastName, email, hashedPassword, phone, secondPhone, stateOfResidence, city, street, address, serviceTypeId, serviceTypeId, openingHour, referralCode, imagePath]);

// //         // Retrieve the providerId
// //         const providerId = providerResult.insertId;

// //         // Insert data into users table with providerId
// //         const insertUserQuery = `
// //             INSERT INTO users (firstName, lastName, email, phone, password, role, userType, providerId)
// //             VALUES (?, ?, ?, ?, ?, ?, ?, ?)
// //         `;
// //         const userResult = await query(insertUserQuery, [firstName, lastName, email, phone, hashedPassword, 'user', 'SkillProvider', providerId]);

// //         // Check if user insertion was successful
// //         if (!userResult.insertId) {
// //             throw new Error('Failed to insert user');
// //         }

// //         // Generate JWT token
// //         const token = signToken(userResult.insertId);

// //         // Return the newly created user data along with the token
// //         return { id: userResult.insertId, token, ...skillProviderData, address };
        
// //     } catch (error) {
// //         throw error;
// //     }
// // };



// skillProviderService.createSkillProvider = async (skillProviderData) => {
//     try {
//         const { firstName, lastName, email, password, phone, secondPhone, stateOfResidence, city, street, serviceType, subCategory, openingHour, referralCode, imagePath } = skillProviderData;

//         // Check if email or phone already exists
//         const emailExists = await skillProviderService.emailExists(email);
//         if (emailExists) {
//             throw new Error('Email already exists');
//         }

//         const phoneExists = await skillProviderService.phoneExists(phone);
//         if (phoneExists) {
//             throw new Error('Phone number already exists');
//         }

//         // Hash the password
//         const hashedPassword = await bcrypt.hash(password, 12);

//         // Construct full address
//         const address = `${street}, ${city}, ${stateOfResidence}`;

//         // Insert data into skill_types table for service type and subcategory if not exists
//         const [serviceTypeResult] = await query('INSERT IGNORE INTO skill_types (serviceType, subCategory) VALUES (?, ?)', [serviceType, subCategory]);

//         // Retrieve the service type and subcategory IDs
//         let serviceTypeId;
//         if (serviceTypeResult) {
//             serviceTypeId = serviceTypeResult.insertId;
//         } else {
//             // Retrieve service type ID if it already exists
//             const serviceTypeQuery = 'SELECT id FROM skill_types WHERE serviceType = ? AND subCategory = ?';
//             const [serviceTypeRow] = await query(serviceTypeQuery, [serviceType, subCategory]);
//             if (serviceTypeRow) {
//                 serviceTypeId = serviceTypeRow.id;
//             } else {
//                 throw new Error('Failed to retrieve service type ID');
//             }
//         }

//         // Insert data into skill_providers table
//         const insertProviderQuery = `
//             INSERT INTO skill_providers (firstName, lastName, email, password, phone, secondPhone, stateOfResidence, city, street, address, serviceTypeId, subCategoryId, openingHour, referralCode, imagePath)
//             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
//         `;
//         const providerResult = await query(insertProviderQuery, [firstName, lastName, email, hashedPassword, phone, secondPhone, stateOfResidence, city, street, address, serviceTypeId, serviceTypeId, openingHour, referralCode, imagePath]);

//         // Retrieve the providerId
//         const providerId = providerResult.insertId;

//         // Insert data into users table with providerId
//         const insertUserQuery = `
//             INSERT INTO users (firstName, lastName, email, phone, password, role, userType, providerId)
//             VALUES (?, ?, ?, ?, ?, ?, ?, ?)
//         `;
//         const userResult = await query(insertUserQuery, [firstName, lastName, email, phone, hashedPassword, 'user', 'SkillProvider', providerId]);

//         // Check if user insertion was successful
//         if (!userResult.insertId) {
//             throw new Error('Failed to insert user');
//         }

//         // Generate JWT token
//         const token = signToken(userResult.insertId);

//         // Return the newly created user data along with the token
//         return { id: userResult.insertId, token, ...skillProviderData, address, serviceType, subCategory };
        
//     } catch (error) {
//         throw error;
//     }
// };


// skillProviderService.getAllSkillProviders = async () => {
//     try {
//         const selectAllQuery = `
//             SELECT sp.*, st.serviceType, st.subCategory 
//             FROM skill_providers sp
//             INNER JOIN skill_types st ON sp.serviceTypeId = st.id AND sp.subCategoryId = st.id
//         `;
//         const skillProviders = await query(selectAllQuery);
//         return skillProviders;
//     } catch (error) {
//         throw error;
//     }
// };

// skillProviderService.getSkillProviderById = async (id) => {
//     try {
//         const selectQuery = `
//             SELECT sp.*, st.serviceType, st.subCategory 
//             FROM skill_providers sp
//             INNER JOIN skill_types st ON sp.serviceTypeId = st.id AND sp.subCategoryId = st.id
//             WHERE sp.id = ?
//         `;
//         const skillProviders = await query(selectQuery, [id]);
//         return skillProviders[0];
//     } catch (error) {
//         throw error;
//     }
// };

// // skillProviderService.updateSkillProviderProfileWithImage = async (providerId, providerData) => {
// //     try {
// //         // Retrieve current skillProvider data from the database
// //         const currentProvider = await skillProviderService.getSkillProviderById(providerId);
// //         if (!currentProvider) {
// //             throw new Error('Skill provider not found');
// //         }

// //         // Construct the updated address
// //         const updatedAddress = [
// //             providerData.stateOfResidence || currentProvider.stateOfResidence,
// //             providerData.city || currentProvider.city,
// //             providerData.street || currentProvider.street
// //         ].filter(Boolean).join(', ');

// //         // Prepare update query based on changed fields
// //         const updateFields = Object.entries(providerData).filter(([key, value]) => value !== currentProvider[key] && key !== 'imagePath');
// //         const updateValues = updateFields.map(([key, value]) => `${key}=?`).join(', ');
// //         const updateParams = updateFields.map(([key, value]) => value);

// //         // Add imagePath and updated address to updateParams
// //         updateParams.push(providerData.imagePath || currentProvider.imagePath);
// //         updateParams.push(updatedAddress);

// //         // Add providerId at the end of updateParams
// //         updateParams.push(providerId);

// //         // Update skill provider data in the database
// //         const updateQuery = `
// //             UPDATE skill_providers 
// //             SET ${updateValues}, imagePath=?, address=?
// //             WHERE id=?
// //         `;
// //         await query(updateQuery, updateParams);

// //         // Return updated skill provider data
// //         return { ...currentProvider, ...providerData, address: updatedAddress };
// //     } catch (error) {
// //         throw error;
// //     }
// // };


// skillProviderService.updateSkillProviderProfileWithImage = async (providerId, providerData) => {
//     try {
//         // Retrieve current skill provider data from the database
//         const currentProvider = await skillProviderService.getSkillProviderById(providerId);
//         if (!currentProvider) {
//             throw new Error('Skill provider not found');
//         }

//         // Construct the updated address
//         const updatedAddress = [
//             providerData.stateOfResidence || currentProvider.stateOfResidence,
//             providerData.city || currentProvider.city,
//             providerData.street || currentProvider.street
//         ].filter(Boolean).join(', ');

//         // Prepare update query based on changed fields
//         const updateFields = Object.entries(providerData).filter(([key, value]) => value !== currentProvider[key] && key !== 'imagePath');
//         const updateValues = updateFields.map(([key, value]) => `${key}=?`).join(', ');
//         const updateParams = updateFields.map(([key, value]) => value);

//         // Add imagePath and updated address to updateParams
//         updateParams.push(providerData.imagePath || currentProvider.imagePath);
//         updateParams.push(updatedAddress);

//         // Add providerId at the end of updateParams
//         updateParams.push(providerId);

//         // Update skill provider data in the database
//         const updateQuery = `
//             UPDATE skill_providers 
//             SET ${updateValues}, imagePath=?, address=?
//             WHERE id=?
//         `;
//         await query(updateQuery, updateParams);

//         // Check if the user exists
//         const userExists = await skillProviderService.userExists(providerId);
//         if (!userExists) {
//             throw new Error('User not found');
//         }

//         // Update user data in the users table
//         const updateUserQuery = `
//             UPDATE users
//             SET firstName = ?, lastName = ?, email = ?, phone = ?
//             WHERE providerId = ?
//         `;
//         await query(updateUserQuery, [providerData.firstName, providerData.lastName, providerData.email, providerData.phone, providerId]);

//         // Return updated skill provider data
//         return { ...currentProvider, ...providerData, address: updatedAddress };
//     } catch (error) {
//         throw error;
//     }
// };



// skillProviderService.deleteSkillProvider = async (id) => {
//     try {
//         const deleteQuery = 'DELETE FROM skill_providers WHERE id = ?';
//         await query(deleteQuery, [id]);
//         return { id };
//     } catch (error) {
//         throw error;
//     }
// };


// // CRUD operations for skill types and subcategories

// skillProviderService.createSkillType = async (serviceType, subCategory) => {
//     try {
//         const insertQuery = 'INSERT INTO skill_types (serviceType, subCategory) VALUES (?, ?)';
//         const result = await query(insertQuery, [serviceType, subCategory]);
//         return result.insertId;
//     } catch (error) {
//         throw error;
//     }
// };

// skillProviderService.getSkillTypeById = async (id) => {
//     try {
//         const selectQuery = 'SELECT * FROM skill_types WHERE id = ?';
//         const result = await query(selectQuery, [id]);
//         return result[0];
//     } catch (error) {
//         throw error;
//     }
// };

// skillProviderService.getAllSkillTypes = async () => {
//     try {
//         const selectAllQuery = 'SELECT * FROM skill_types';
//         const result = await query(selectAllQuery);
//         return result;
//     } catch (error) {
//         throw error;
//     }
// };

// skillProviderService.updateSkillType = async (id, serviceType, subCategory) => {
//     try {
//         const updateQuery = 'UPDATE skill_types SET serviceType=?, subCategory=? WHERE id=?';
//         await query(updateQuery, [serviceType, subCategory, id]);
//         return { id, serviceType, subCategory };
//     } catch (error) {
//         throw error;
//     }
// };

// skillProviderService.deleteSkillType = async (id) => {
//     try {
//         const deleteQuery = 'DELETE FROM skill_types WHERE id = ?';
//         await query(deleteQuery, [id]);
//         return { id };
//     } catch (error) {
//         throw error;
//     }
// };


// module.exports = skillProviderService;


const mysql = require('mysql');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const axios = require('axios');
const dotenv = require('dotenv');

dotenv.config();

const connection = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
});

// Helper function to execute SQL queries
function query(sql, args) {
    return new Promise((resolve, reject) => {
        connection.query(sql, args, (err, rows) => {
            if (err) reject(err);
            else resolve(rows);
        });
    });
}

// Function to sign JWT token
const signToken = (id) => {
    return jwt.sign({ id }, process.env.JWT_SECRET, {
        expiresIn: process.env.JWT_EXPIRES_IN,
    });
};



async function createSkillProvidersTable() {
    const createSkillProvidersTableQuery = `
        CREATE TABLE IF NOT EXISTS skill_providers (
            id INT AUTO_INCREMENT PRIMARY KEY,
            firstName VARCHAR(255) NOT NULL,
            lastName VARCHAR(255) NOT NULL,
            email VARCHAR(255),
            password VARCHAR(255) NOT NULL,
            phone VARCHAR(20),
            secondPhone VARCHAR(20),
            stateOfResidence VARCHAR(255) NOT NULL,
            city VARCHAR(255) NOT NULL,
            street VARCHAR(255) NOT NULL,
            address VARCHAR(255),
            serviceType VARCHAR(255),
            subCategory VARCHAR(255),
            openingHour VARCHAR(255),
            referralCode VARCHAR(255),
            imagePath VARCHAR(255),
            userId INT,
            FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
            latitude DECIMAL(10, 8),
            longitude DECIMAL(11, 8),
            createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
    `;
    try {
        await query(createSkillProvidersTableQuery);
        console.log('SkillProviders table created successfully');
    } catch (error) {
        console.error('Error creating SkillProviders table:', error);
        throw error;
    }
}


createSkillProvidersTable(); // Immediately create the table on module load

const skillProviderService = {};


skillProviderService.emailExists = async (email) => {
    try {
        let selectQuery;
        let queryParams;
        
        if (email === null) {
            selectQuery = 'SELECT COUNT(*) AS count FROM skill_providers WHERE email IS NULL';
            queryParams = [];
        } else {
            selectQuery = 'SELECT COUNT(*) AS count FROM skill_providers WHERE email = ?';
            queryParams = [email];
        }

        const result = await query(selectQuery, queryParams);
        const count = result[0].count;
        return count > 0;
    } catch (error) {
        throw error;
    }
};


skillProviderService.phoneExists = async (phone) => {
    try {
        const selectQuery = 'SELECT COUNT(*) AS count FROM users WHERE phone = ?';
        const result = await query(selectQuery, [phone]);
        const count = result[0].count;
        return count > 0;
    } catch (error) {
        throw error;
    }
};

// skillProviderService.createSkillProvider = async (skillProviderData) => {
//     try {
//         const { firstName, lastName, email, password, phone, secondPhone, stateOfResidence, city, street, serviceType, subCategory, openingHour, referralCode, imagePath } = skillProviderData;

//         // Check if email or phone already exists
//         const emailExists = await skillProviderService.emailExists(email);
//         if (emailExists) {
//             throw new Error('Email already exists');
//         }

//         const phoneExists = await skillProviderService.phoneExists(phone);
//         if (phoneExists) {
//             throw new Error('Phone number already exists');
//         }

//         // Hash the password
//         const hashedPassword = await bcrypt.hash(password, 12);

//         // Construct full address
//         const address = `${street}, ${city}, ${stateOfResidence}`;

//         // Create new user
//         const newUserQuery = 'INSERT INTO users (firstName, lastName, email, phone,  password, role, userType) VALUES (?, ?, ?, ?, ?, ?, ?)';
//         const newUserResult = await query(newUserQuery, [firstName, lastName, email, phone,  hashedPassword, 'user', 'SkillProvider']);

//         // Generate JWT token
//         const token = jwt.sign({ id: newUserResult.insertId }, process.env.JWT_SECRET, {
//             expiresIn: process.env.JWT_EXPIRES_IN,
//         });

//         // Insert skillProvider data into the skill_providers table
//         const insertQuery = `
//             INSERT INTO skill_providers (firstName, lastName, email, password, phone, secondPhone, stateOfResidence, city, street, address, serviceType, subCategory, openingHour, referralCode, imagePath, userId)
//             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
//         `;
//         const result = await query(insertQuery, [firstName, lastName, email, hashedPassword, phone, secondPhone, stateOfResidence, city, street, address, serviceType, subCategory, openingHour, referralCode, imagePath, newUserResult.insertId]);

//         return { id: result.insertId, token, ...skillProviderData, address, imagePath };
//     } catch (error) {
//         throw error;
//     }
// };


skillProviderService.createSkillProvider = async (skillProviderData) => {
    try {
        const { firstName, lastName, email, password, phone, secondPhone, stateOfResidence, city, street, serviceType, subCategory, openingHour, referralCode, imagePath } = skillProviderData;

        // Check if email or phone already exists
       // Check if email is null
    //    if (!email) {
    //         throw new Error('Email was not assigned');
    //     }

        const phoneExists = await skillProviderService.phoneExists(phone);
        if (phoneExists) {
            throw new Error('Phone number already exists');
        }

        const emailExists = await skillProviderService.emailExists(email);
        if (emailExists) {
            throw new Error('Email already exists');
        }
        // Hash the password
        const hashedPassword = await bcrypt.hash(password, 12);

        // Construct full address
        const address = `${street}, ${city}, ${stateOfResidence}`;

        // Insert data into skill_providers table
        const insertProviderQuery = `
            INSERT INTO skill_providers (firstName, lastName, email, password, phone, secondPhone, stateOfResidence, city, street, address, serviceType, subCategory, openingHour, referralCode, imagePath)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `;
        const providerResult = await query(insertProviderQuery, [firstName, lastName, email, hashedPassword, phone, secondPhone, stateOfResidence, city, street, address, serviceType, subCategory, openingHour, referralCode, imagePath]);

        // Retrieve the providerId
        const providerId = providerResult.insertId;

        // Insert data into users table with providerId
        const insertUserQuery = `
            INSERT INTO users (firstName, lastName, email, phone, password, role, userType, providerId)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `;
        const userResult = await query(insertUserQuery, [firstName, lastName, email, phone, hashedPassword, 'user', 'SkillProvider', providerId]);

        // Check if user insertion was successful
        if (!userResult.insertId) {
            throw new Error('Failed to insert user');
        }

        // Generate JWT token
        const token = signToken(userResult.insertId);

        // Return the newly created user data along with the token
        return { id: userResult.insertId, token, ...skillProviderData, address };
        
    } catch (error) {
        throw error;
    }
};


skillProviderService.getAllSkillProviders = async () => {
    try {
        const selectAllQuery = 'SELECT * FROM skill_providers';
        const skillProviders = await query(selectAllQuery);
        return skillProviders;
    } catch (error) {
        throw error;
    }
};

skillProviderService.getSkillProviderById = async (id) => {
    try {
        const selectQuery = 'SELECT * FROM skill_providers WHERE id = ?';
        const skillProviders = await query(selectQuery, [id]);
        return skillProviders[0];
    } catch (error) {
        throw error;
    }
};

skillProviderService.updateSkillProviderProfileWithImage = async (providerId, providerData) => {
    try {
        // Retrieve current skillProvider data from the database
        const currentProvider = await skillProviderService.getSkillProviderById(providerId);
        if (!currentProvider) {
            throw new Error('Skill provider not found');
        }

        // Construct the updated address
        const updatedAddress = [
            providerData.stateOfResidence || currentProvider.stateOfResidence,
            providerData.city || currentProvider.city,
            providerData.street || currentProvider.street
        ].filter(Boolean).join(', ');

        // Prepare update query based on changed fields
        const updateFields = Object.entries(providerData).filter(([key, value]) => value !== currentProvider[key] && key !== 'imagePath');
        const updateValues = updateFields.map(([key, value]) => `${key}=?`).join(', ');
        const updateParams = updateFields.map(([key, value]) => value);

        // Add imagePath and updated address to updateParams
        updateParams.push(providerData.imagePath || currentProvider.imagePath);
        updateParams.push(updatedAddress);

        // Add providerId at the end of updateParams
        updateParams.push(providerId);

        // Update skill provider data in the database
        const updateQuery = `
            UPDATE skill_providers 
            SET ${updateValues}, imagePath=?, address=?
            WHERE id=?
        `;
        await query(updateQuery, updateParams);

        // Return updated skill provider data
        return { ...currentProvider, ...providerData, address: updatedAddress };
    } catch (error) {
        throw error;
    }
};


skillProviderService.deleteSkillProvider = async (id) => {
    try {
        const deleteQuery = 'DELETE FROM skill_providers WHERE id = ?';
        await query(deleteQuery, [id]);
        return { id };
    } catch (error) {
        throw error;
    }
};

module.exports = skillProviderService;


